package com.dam2.extraescolar.model.dao;

import java.util.List;

import com.dam2.extraescolar.model.entity.Grupo;

public class GruposDao extends GenericDao<Grupo, Integer> {

	@Override
	public Grupo get(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Grupo get(Grupo entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer add(Grupo entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(List<Grupo> list) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Grupo entity) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Grupo next(Grupo entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Grupo previous(Grupo entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Grupo> listAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Grupo> listNext(int rows) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Grupo> listPrevious(int rows) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean exist(Grupo entity) {
		// TODO Auto-generated method stub
		return false;
	}
}