package repaso;

public class ejercicio0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Primer ejercicio de JAVA");
		System.out.println("Pruebas de Eclipse");
	}

}
