package ejercicio4;

public class Main {

	public static void main(String[] args) {
		// 4. Escriba un programa que pida el número de día de un mes y visualice las horas
		//transcurridas desde inicio del mes

		System.out.println("horas transcurridas hasta el día 18 : "+
		UtilFecha.horasTranscurridasMes(18)+ " horas");
	}

}
