package ejercicio3;

public class Main {

	public static void main(String[] args) {
	System.out.println(" 3 días, 5 horas y 8 minutos son :");
	System.out.println(UtilFecha.ddhhmmToSegundos(3, 5, 8)+" segundos.");
	
	
	
	}

}
