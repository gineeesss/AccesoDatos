package repositorio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.Coche;
import util.ConexionBBDD;

public class CocheRepository implements Repository<Coche> {
		
	private static Connection con = ConexionBBDD.getInstance();
	
	
	@Override
	public void insertar(Coche coche) {
		String sql = "INSERT INTO coche VALUES (?,?,?,?);";
		try(
			PreparedStatement st = con.prepareStatement(sql);
			){
			
			st.setString(1, coche.getMatricula() );
			st.setString(2, coche.getMarca());
			st.setString(3, coche.getModelo());
			st.setString(4, coche.getColor());
			
			st.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("Error al insertar un coche en la base de datos");
			System.err.println(e.getMessage());
		}
	}

	@Override
	public void actualizar(String matricula, Coche coche) {
		String sql = "UPDATE coche SET marca = ? , modelo = ? WHERE matricula = ?;";
		try(
			PreparedStatement st = con.prepareStatement(sql);
			){
			
			st.setString(1, coche.getMarca() );
			st.setString(2, coche.getModelo());
			st.setString(3, matricula);
			
			st.executeUpdate();
			
		} catch (SQLException e) {
			System.err.println("Error al actualizar un coche en la base de datos");
			System.err.println(e.getMessage());
		}
		
	}

	@Override
	public void eliminar(String matricula) {
		String sql = "DELETE FROM coche WHERE matricula=?;";
		try(
			PreparedStatement st = con.prepareStatement(sql);
			){
		
			st.setString(1, matricula);
			
			st.execute();
			
		} catch (SQLException e) {
			System.err.println("Error al eliminar un coche de la base de datos");
			System.err.println(e.getMessage());
		}
		
	}
	
	public ArrayList buscarVolvo() {
		ArrayList<Coche> volvos = new ArrayList();
		
		String sql = "SELECT * FROM coche WHERE marca = 'volvo';";
		
		try(
				Statement st = con.createStatement();
				ResultSet rs= st.executeQuery(sql);
				)
		{
			
			if (rs!=null) {
				
				while(!rs.last()) {
					Coche coche = new Coche();
					coche.setMatricula(rs.getString(1));
					coche.setMarca(rs.getString(2));
					coche.setModelo(rs.getString(3));
					coche.setColor(rs.getString(4));
				
					volvos.add(coche);	
					rs.next();

				}
			} else {
				System.out.println("No hay volvo en la base de datos");
			}
			
		} catch (SQLException e) {
			System.err.println("Error al recuperar volvos");
			System.err.println(e.getMessage());
		}
		return volvos;
	}
	
	

}
