package snippet;

public class Snippet {
	public static void main(String[] args) {
		
		System.out.println("Inserta a continuación: Matricula + Marca + Modelo + Color");
	}
}

